package editor;

import java.awt.Image;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import editor.loaders.BitMap;
import editor.loaders.LevelFile;
import editor.lvz.ProgressFrame;
import editor.xml.XMLNode;

public class Editor extends JScrollPane
{	
	//The file where the lvl was opened from
	private File		m_file;
	//The main class so we can add windows
	public Main		m_main;
	//The levelfile
	public LevelFile 	m_lvlFile;
	
	protected String m_fileName;
	
	protected Image m_tileset;
	protected Image[] m_tiles;
	protected short[][] m_map;
	
	//The window for which the scrollpane views
	protected LevelWindow	m_window;
	

	/** Creates a new editor instance, this constructor should be called for a
	 * new lvl file.
	 */
	public Editor( Main main) 
	{				
		m_main = main;
		//Set unit increments
        getHorizontalScrollBar().setUnitIncrement( 16 );
        getVerticalScrollBar().setUnitIncrement( 16 );
        
        //Create our lvl file
        BitMap bmp = loadDefaultTileset();
		m_lvlFile = new LevelFile( bmp );
		m_tileset = m_lvlFile.getTileSet();    
		
		m_map = m_lvlFile.getMap();
		
		
//		Create our display are and set to view it
			  m_window = new LevelWindow( this,m_main.getSelectedTool() );
			  setViewportView( m_window );
			  
		
		m_tiles = m_lvlFile.getTiles();
		
		//Set file name
		m_fileName = "(Untitled Map)";
	}

	public Editor( File file, Main main ) {
	
	
		m_file = file;
		m_main = main;
		
		//Set unit increments
        getHorizontalScrollBar().setUnitIncrement( 16 );
        getVerticalScrollBar().setUnitIncrement( 16 );
        
		//Set file name
		m_fileName = file.getName();      
	}
	
	/**
	 * Load a map
	 * @return true iff sucessful
	 */
	public boolean load() 
	{
		
		ProgressFrame pf = new ProgressFrame("Progress");
		String errorWithELVL = null;
		
		try {
        	//Gets running directory
        	File f = new File( "" );        	
			
			pf.setProgress("Loading " + m_file.getAbsolutePath());
			
			//Read in bitmap portion of map
			BufferedInputStream bs = new BufferedInputStream( new FileInputStream( m_file ) );
			BitMap bmp = new BitMap( bs );
			bmp.readBitMap( false );
			
			if( bmp.isBitMap() ) {
				m_lvlFile = new LevelFile( m_file, bmp, true, bmp.hasELVL );
			} else {
				bmp = loadDefaultTileset();
				m_lvlFile = new LevelFile( m_file, bmp, false, bmp.hasELVL );
			}
			errorWithELVL = m_lvlFile.readLevel();
			
			if (errorWithELVL != null)
			{
				
				m_lvlFile = new LevelFile( m_file, bmp, false, false ); // attempt load without meta data
				String error = m_lvlFile.readLevel();
				
				if (error != null)
				{ // I give up
					System.out.println("First error = " + errorWithELVL);
					System.out.println("NON eLVL Load: " + error);
					
					throw new IOException("Corrupt LVL File");
				}
				else
				{
					System.out.println("NON eLVL Load sucessful! Previous error: " + errorWithELVL);
				}
			}
			
			m_tileset = m_lvlFile.getTileSet();
			
			m_map = m_lvlFile.getMap();
			m_tiles = m_lvlFile.getTiles();
			
			//Create our display are and set to view it
		   m_window = new LevelWindow( this, m_main.getSelectedTool( ));
		   setViewportView( m_window );
		   
		   if (m_lvlFile.regions != null)
				m_window.m_asssRegions.setRegions(m_lvlFile.regions);
			
			m_window.m_lvzImages.loadLvzImages(m_file,pf);
			
			m_window.undoer = new Undoer(m_window);
			
			String name = m_file.getAbsolutePath();
		
			if (name.length() < 4)
			{
				pf.hide();
				return true;
			}
				
			String directory = name.substring(0,name.length() - 4) + " files" + File.separator;
			
			if (!new File(directory + "setup.xml").exists())
			{
				pf.hide();
				return true;
			}
				
			pf.setProgress("Loading setup.xml");
			
			XMLNode document = XMLNode.readDocument(directory + "setup.xml");
			
			XMLNode setup = document.getChild("Setup");
			if (setup == null)
			{
				JOptionPane.showMessageDialog(null,"setup.xml problem: no Setup child");
			}
			else // setup exists
			{			
				XMLNode regions = setup.getChild("Regions");
				
				if (regions != null)
				{
					m_window.m_asssRegions.loadRegions(regions);
				}
				
				XMLNode att = setup.getChild("AutotoolTiles");
				
				if (att != null)
				{
					m_window.m_autotool.loadFromXMLNode(att);
				}
			}
			pf.hide();
			
			if (errorWithELVL != null)
			{
				System.out.println("Error with eLVL Data!");
				JOptionPane.showMessageDialog(null,"Error loading with eLVL Data: " + errorWithELVL);
			}
			
			return true;
				
			} 
			catch (IOException e) 
			{
				 // Create our lvl file
				 BitMap bmp = loadDefaultTileset();
				 m_lvlFile = new LevelFile( bmp );

				 m_tileset = m_lvlFile.getTileSet();
				 m_map = m_lvlFile.getMap();
				 m_tiles = m_lvlFile.getTiles();

				 //Set file name
				 m_fileName = "(Untitled Map)";
					 
				JOptionPane.showMessageDialog(null,e);
				
			}
			
		pf.hide();
		return false;
	}
	
	public void save() 
	{		
		String name = m_lvlFile.m_file.getAbsolutePath();
		
		if (name.length() < 4)
			return;
					
		ProgressFrame pf = new ProgressFrame("Progress");
		pf.setProgress("Saving " + m_lvlFile.m_file.getAbsolutePath());
		
		if (m_window.selection != null) // place selection if it exists
		{
			m_window.placeSelection();
			m_window.selection = null;
		}
		
		
		m_lvlFile.saveLevel(m_tileset,m_map,m_window.m_asssRegions.getRegions());
		
		m_window.m_lvzImages.saveLvz( m_lvlFile.m_file,pf); // also makes directory
		
		pf.setProgress("Saving setup.xml");
		
		XMLNode document = new XMLNode();
		XMLNode setup = document.addChild("Setup");
		setup.children = new Vector();
		
		//XMLNode regionNode = m_window.m_asssRegions.saveRegions(m_lvlFile.m_file,pf);
		//if (regionNode != null)
	//		setup.children.add(regionNode);
		
		XMLNode attNode = m_window.m_autotool.toXMLNode();
		if (attNode != null)
			setup.children.add(attNode);
		
		String directory = name.substring(0,name.length() - 4) + " files" + File.separator;
		
		XMLNode.saveDocument(document,directory + "setup.xml");
		
		pf.hide();
		
		m_window.modified = false;
		
		m_main.buttonPen.doClick();
	}
	
	public void saveAs(File where) 
	{
		m_lvlFile.m_file = where;
		m_fileName = where.getName();
		
		save();
			
	}
	
	private BitMap loadDefaultTileset() {
		try {
			File f = new File( "" );
			File file = new File( f.getAbsolutePath()+"/include/default.bmp" );
			BufferedInputStream bs = new BufferedInputStream( new FileInputStream( file ) );
			BitMap bmp = new BitMap( bs );
			bmp.readBitMap( false );
			return bmp;
		} catch (FileNotFoundException e ) {
		}
		return null;
	}
	
	public void gotFocus() {
		m_window.gotFocus();
	}
	
	public void lostFocus() {
		m_window.lostFocus();
	}	
}