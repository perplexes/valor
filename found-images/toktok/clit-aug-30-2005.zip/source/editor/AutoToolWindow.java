package editor;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import editor.xml.XMLNode;

public class AutoToolWindow extends JInternalFrame {//implements MouseListener {
	
	private AutoTool		m_child;

	/** Constructor for TilesetWindow which displays the current tileset.
	 * It reads the tileset from Editor.java which keeps it up to date even
	 * when the tileset may change through import or edit.
	 * @param parent The parent class which creates this instance
	 */	
	public AutoToolWindow( LevelWindow parent, ProjectState state ) {
		
		//set frame title, and closable
		super( "EZ", false, true, false, false );

		//Just hide the frame when closed, parent class listens for event	
		setDefaultCloseOperation( WindowConstants.HIDE_ON_CLOSE );
		
		//Hide the 'java' icon
		try {
			setFrameIcon( null );
		} catch( Exception e) {
		}

		//Create our child and add it into the frame
		m_child = new AutoTool( parent, state );
		getContentPane().add( m_child );
		
		//Set the default location then show 
		/**** TO DO - Possibly make setLocation dependant on parent size ****/
		setLocation( state.pos_Autotool.x, state.pos_Autotool.y );	
		pack();
		show();
	}
	
	// for saving
	public XMLNode toXMLNode()
	{
		XMLNode autoToolTiles = new XMLNode();
		autoToolTiles.name = "AutotoolTiles";
		
		for( int y = 0; y < 4; y++ ) for( int x = 0; x < 4; x++ ) 
		{
			autoToolTiles.addChild("Tile" + (x + y * 4),"" + m_child.m_state.autoTileset[x][y]);
		}
		
		return autoToolTiles;
	}
	
	public void loadFromXMLNode(XMLNode autoToolTiles)
	{
		for( int y = 0; y < 4; y++ ) for( int x = 0; x < 4; x++ ) 
		{
			short tile = 0;
			
			XMLNode num = autoToolTiles.getChild("Tile" + (x + y * 4));
			
			if (num != null)
			{
				tile = (short)num.getIntValue();
			}
			
			m_child.m_state.autoTileset[x][y] = tile;
		}
		
		repaint();
	}

}

class AutoTool extends JPanel implements MouseListener {
	
	private LevelWindow m_parent;
	public ProjectState m_state;
	private Image autoBackground = new ImageIcon("include" + File.separator + "Images" + File.separator 
		+ "AutoBackground.png").getImage();
	
	public AutoTool( LevelWindow parent, ProjectState state ) {
		m_parent = parent;
		m_state = state;
		setSize( 64, 64 );
		setPreferredSize( new Dimension( 64, 64 ) );
		addMouseListener( this );
		setBackground(Color.black);
	}
	
	protected void paintComponent( Graphics g ) {
		
		super.paintComponent( g );
		
		g.drawImage(autoBackground,0,0,null);
		
		Image[] m_tiles = m_parent.m_parent.m_tiles;
		
		//draw tiles
		for( int x = 0; x < 4; x++ )
			for( int y = 0; y < 4; y++ )
				if( m_state.autoTileset[x][y] > 0 ) 
				g.drawImage( m_tiles[m_state.autoTileset[x][y]-1], x * 16, y * 16, 16, 16, this );
	}
	
	/** Used to listen to mousePressed events and set the selected tiles
	 */
	public void mousePressed(MouseEvent e) {
    	
    	Insets insets = getInsets();
		int x = e.getX() - insets.left;
		int y = e.getY() - insets.top;
		
		x /= 16;
		y /= 16;
		
		if (x > 4 || y > 4)
			return;
			
		int tile =  m_parent.m_tileset.getTile( e.getButton() );
		
		if (tile > 191) // don't allow special tiles
			return;
				
		m_state.autoTileset[x][y] = (short)tile;
		
		//Call a repaint so the new tile selected is shown
		repaint();
    }
    
    public void mouseReleased(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
	public void mouseClicked(MouseEvent e) {} 
}