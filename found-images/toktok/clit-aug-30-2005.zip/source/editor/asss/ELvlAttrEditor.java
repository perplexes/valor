/*
 * Created on Dec 29, 2004
 *
 */
package editor.asss;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

/**
 * The eLVL ATTR edtior Panel
 * @author baks
 */
public class ELvlAttrEditor extends JDialog implements ActionListener
{
	private Vector d;
	private JButton add = new JButton("Add New Row");
	private JButton remove = new JButton("Remove Selected Row");
	private JButton close = new JButton("Close Window");
	private JTable table; 
	private static Vector colums = new Vector();
	
	static
	{
		colums.add("<key>");
		colums.add("<value>");
	}
	
	/**
	 * Make a new Dialog
	 * @param parent the parent frame
	 * @param data the data to edit as a vector of Strings
	 */
	private ELvlAttrEditor(JFrame parent,Vector data)
	{
		super(parent, true);
		d = data;
		setTitle("eLVL ATTR Editor");
		setSize(370,250);
		setLocation(parent.getX() + parent.getWidth() / 2 - getWidth()/2,
								  parent.getY() + parent.getHeight() / 2 - getHeight()/2);
		 
		table = new JTable(d,colums); 
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setPreferredScrollableViewportSize(new Dimension(330,110));
		table.getColumnModel().getColumn(0).setPreferredWidth(110);
		table.getColumnModel().getColumn(1).setPreferredWidth(220);
		JScrollPane scrollPane = new JScrollPane(table);

		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		JPanel center = new JPanel();
		center.setLayout(new FlowLayout());
		center.add(scrollPane);
		c.add(center);
		
		JPanel north = new JPanel();
		north.setLayout(new FlowLayout());
		
		north.add(add);
		add.addActionListener(this);
		north.add(remove);
		remove.addActionListener(this);
		c.add(north,BorderLayout.NORTH);
		
		JPanel south = new JPanel();
		south.setLayout(new FlowLayout());
		south.add(new JLabel("Make sure you press enter after any changes."));
		south.add(close);
		close.addActionListener(this);
		
		c.add(south,BorderLayout.SOUTH);
		
	}

	/**
	 * Edit the elvl attributes stored in a vector
	 * @param editThis the vector of strings representing ATTR tags
	 * @param parent the parent jframe for this modal dialog
	 */
	public static void editAttrs(Vector editThis, JFrame parent)
	{
		ELvlAttrEditor e = new ELvlAttrEditor(parent,editThis);
		e.show();
	}
	
	// EVENTS
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == close)
			hide();
		else if (e.getSource() == add)
		{
			Vector row = new Vector();
			row.add("TAGSTRING");
			row.add("VALUESTRING");
			d.add(row);
			table.revalidate();
		}
		else if (e.getSource() == remove)
		{
			if (table.getRowCount() > 0)
			{
				int row = table.getSelectedRow();
				
				if (row != -1)
				{
					d.remove(row);
					table.revalidate();
				}
			}
		}
	}
}
