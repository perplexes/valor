Continuum Level / Ini Tool by 2dragons and Vampz! BETA 8-10-05

Thank you for trying our software!

This program places lvz images right on the map as well as edits lvl files and visually adds asss regions.

Double click "Continuum_Level_Ini_Tool_7-23-05.jar" to start the program. You need JRE (Java Runtime Environment) which is a free download at http://java.sun.com/j2se/1.5.0/download.jsp

If it's not working when you double click, find the path of Java.exe (search in program files\Java\) and do run
"java.exe -jar Continuum_Level_Ini_Tool_7-23-05.jar"

Open a .lvl file than import any lvz you want using the Lvz Image Window or create your own lvz!

This is a prerelease. After a few weeks of fixing bugs in this version, this will become the release.

Product is made by 2dragons and Bak, although some parts aren't, namely:

Continuum graphics
(by VIE?)

JAI (Java Advanced Imaging)
for more info on distributing products with JAI I'm going to refer you to java.sun.com and hope you find all the legal stuff there.

This software (with the exception of the above parts) and it's source is distrubuted under GPL and does not come with any warrenty at all... not even that it works! For a more official statement of GPL see lisense.txt

Updates:
8-5-04 Initial Release

8-6-04 Fixed region issues brought forward by Dr Brain

1-1-05 Increased draw speed while decreasing memory usage, Added square and squarefill tools, added support for eLVL ATTR and REGN tags, as well as additional region option made availble through eLVL.

3-18-05 Added cross platform support by encorperating X-LvzToolkit into CLIT. Fixed LvzImageWindow disappearing forever bug.

7-23-05 Added a buttload of features as well as some bug fixes. Most notably we have undo/redo, support for extra continuum tiles, retiling, and a bunch more selection specific features (flipping, rotating, eztiling to name a few).

7-25-05 Fixed the special tiles not erasing bug and added a delete option for selections

7-26-05 Fixed the Apply Ez Tile occasionally not working bug

8-10-05 Fixed the region issues (again?) brought forward by Dr Brain and layout issue with the region window discussed by Smong

8-25-05 Fixed More Layout Issues brought forward by Smong

8-30-05 Added alternate hotkeys for zooming in preferences; using the menu zoom now zooms to the center of the screen. Use of the radar will be remembered across sessions.