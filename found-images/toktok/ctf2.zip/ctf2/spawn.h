/*
	MERVBot Spawn-callback by Catid@pacbell.net
*/

#ifndef SPAWN_H
#define SPAWN_H

#define STRING_CAST_CHAR
#include "..\dllcore.h"


union itemInfo
{
	struct
	{
		unsigned shields	: 1;	// Has it or not
		unsigned supers		: 1;
		unsigned burst		: 4;	// Item counts
		unsigned repel		: 4;
		unsigned thor		: 4;
		unsigned brick		: 4;
		unsigned decoy		: 4;
		unsigned rocket		: 4;
		unsigned portal		: 4;
		unsigned pack		: 2;	// Probably used somehow
	};

	Uint32 n;
};

union weaponInfo
{
	struct
	{
		unsigned type		: 5;	// enum Projectile_Types
		unsigned level		: 2;	// Only for bombs/bullets
		unsigned bouncing	: 1;	// Only for bombs
		unsigned emp		: 1;	// Only for bombs
		unsigned isBomb		: 1;	// ? This is a bomb
		unsigned shrapCount	: 5;	// 0-31
		unsigned fireType	: 1;	// Bombs -> Mines, Bullets -> Multifire
	};

	Uint16 n;
};

enum Projectile_Types
{
	// Seen "in the wild"
	PROJ_None,
	PROJ_Bullet,
	PROJ_BBullet,
	PROJ_Bomb,
	PROJ_PBomb,
	PROJ_Repel,
	PROJ_Decoy,
	PROJ_Burst,
	PROJ_Thor,

	// Internal to the bot
	PROJ_InactiveBullet,
	PROJ_Shrapnel
};

enum Weapon_Levels
{
	LVL_One,
	LVL_Two,
	LVL_Three,
	LVL_Four
};

enum Ship_Types
{
	SHIP_Warbird,		// 0
	SHIP_Javelin,
	SHIP_Spider,
	SHIP_Leviathan,
	SHIP_Terrier,
	SHIP_Weasel,
	SHIP_Lancaster,
	SHIP_Shark,
	SHIP_Spectator		// 8
};

enum Prize_Types
{
	PRIZE_Unknown,		// 0
	PRIZE_Recharge,
	PRIZE_Energy,
	PRIZE_Rotation,
	PRIZE_Stealth,
	PRIZE_Cloak,
	PRIZE_XRadar,
	PRIZE_Warp,
	PRIZE_Guns,
	PRIZE_Bombs,
	PRIZE_BBullets,
	PRIZE_Thruster,
	PRIZE_TopSpeed,
	PRIZE_FullCharge,
	PRIZE_EngineShutdown,
	PRIZE_Multifire,
	PRIZE_Proximity,
	PRIZE_Super,
	PRIZE_Shields,
	PRIZE_Antiwarp,
	PRIZE_Repel,
	PRIZE_Burst,
	PRIZE_Decoy,
	PRIZE_Thor,
	PRIZE_Multiprize,
	PRIZE_Brick,
	PRIZE_Rocket,
	PRIZE_Portal,		// 28
};

enum Chat_SoundBytes
{							// Soundcodes courtesy of MGB
	SND_None,				// 0  = Silence
	SND_BassBeep,			// 1  = BEEP!
	SND_TrebleBeep,			// 2  = BEEP!
	SND_ATT,				// 3  = You're not dealing with AT&T
	SND_Discretion,			// 4  = Due to some violent content, parental discretion is advised
	SND_Hallellula,			// 5  = Hallellula
	SND_Reagan,				// 6  = Ronald Reagan
	SND_Inconceivable,		// 7  = Inconceivable
	SND_Churchill,			// 8  = Winston Churchill
	SND_SnotLicker,			// 9  = Listen to me, you pebble farting snot licker
	SND_Crying,				// 10 = Crying
	SND_Burp,				// 11 = Burp
	SND_Girl,				// 12 = Girl
	SND_Scream,				// 13 = Scream
	SND_Fart,				// 14 = Fart1
	SND_Fart2,				// 15 = Fart2
	SND_Phone,				// 16 = Phone ring
	SND_WorldUnderAttack,	// 17 = The world is under attack at this very moment
	SND_Gibberish,			// 18 = Gibberish
	SND_Ooooo,				// 19 = Ooooo
	SND_Geeee,				// 20 = Geeee
	SND_Ohhhh,				// 21 = Ohhhh
	SND_Ahhhh,				// 22 = Awwww
	SND_ThisGameSucks,		// 23 = This game sucks
	SND_Sheep,				// 24 = Sheep
	SND_CantLogIn,			// 25 = I can't log in!
	SND_MessageAlarm,		// 26 = Beep
	SND_StartMusic = 100,	// 100= Start music playing
	SND_StopMusic,			// 101= Stop music
	SND_PlayOnce,			// 102= Play music for 1 iteration then stop
	SND_VictoryBell,		// 103= Victory bell
	SND_Goal				// 104= Goal!
};

enum Chat_Modes
{
    MSG_Arena,			// 00 Same for *arena, *zone, *szone, **
    MSG_PublicMacro,	// 01 Macro calcs are done client-side
    MSG_Public,			// 02 Public chat
    MSG_Team,			// 03 (//) or (')
    MSG_TeamPrivate,	// 04 Player to all members of another team (")
    MSG_Private,		// 05 Only shows messages addressed to the bot
    MSG_PlayerWarning,	// 06 Red message, with a name tag
    MSG_RemotePrivate,	// 07 Do not trust the sender with any private information.
    MSG_ServerError,	// 08 Red server errors, without a name tag
    MSG_Channel			// 09 Arrives in the same format SubSpace displays
};

union objectInfo
{
	struct
	{
		unsigned id				: 15;	// Object ident
		unsigned disabled		: 1;	// 1=off, 0=on
	};

	Uint16 n;
};

struct PlayerTag
{
	Player *p;
	int index;
	int data;
};

// Increase this beyond 1 when Continuum supports LVZ object toggling with more than 1 object at a time.
#define MAX_OBJECTS 1

#include "ctf.h"
#include "mt.h"
#include "keygen.h"
using namespace cat;

class botInfo
{
	bool CONNECTION_DENIED;

	_linkedlist <PlayerTag> taglist;
	int get_tag(Player *p, int index);
	void set_tag(Player *p, int index, int data);
	void killTags(Player *p);
	void killTags();

	CALL_HANDLE handle;
	CALL_COMMAND callback;
	CALL_PLIST playerlist;
	CALL_FLIST flaglist;
	CALL_MAP map;
	CALL_BLIST bricklist;
	char *arena;
	arenaSettings *settings;
	Player *me;
	bool biller_online;

	objectInfo object_array[MAX_OBJECTS];
	int num_objects;
	Player *object_dest;

	int countdown[5];

	// Put bot data here

	CTFInfo ctf;

	bool enabled;

	RandomMT prng;

	bool awardNextSeenJackpot;
	uint16 awardTeam, awardAdditionalPoints;
	String victoryString;

	bool greeter;

	uint32 gameStartTime;

	bool tkchecker;

	int positionToggle;

public:
	botInfo(CALL_HANDLE given)
	{
		handle = given;
		callback = 0;
		playerlist = 0;
		flaglist = 0;
		map = 0;
		countdown[0] = 0;
		countdown[1] = 0;
		countdown[2] = 90;
		countdown[3] = 600;
		countdown[4] = 10;
		CONNECTION_DENIED = false;
		me = 0;
		biller_online = true;
		num_objects = 0;
		object_dest = NULL;

		// Put initial values here

		enabled = true;
		awardNextSeenJackpot = false;
		greeter = true;
		tkchecker = true;
		positionToggle = 0;
	}

	void moveNext();

	void clear_objects();
	void object_target(Player *p);
	void toggle_objects();
	void queue_enable(int id);
	void queue_disable(int id);

	void gotEvent(BotEvent &event);

	void tell(BotEvent &event);

	bool validate(CALL_HANDLE given) { return given == handle; }

	void sendPrivate(Player *player, char *msg);
	void sendPrivate(Player *player, BYTE snd, char *msg);

	void sendTeam(char *msg);
	void sendTeam(BYTE snd, char *msg);

	void sendTeamPrivate(Uint16 team, char *msg);
	void sendTeamPrivate(Uint16 team, BYTE snd, char *msg);

	void sendPublic(char *msg);
	void sendPublic(BYTE snd, char *msg);

	void sendPublicMacro(char *msg);
	void sendPublicMacro(BYTE snd, char *msg);

	void sendChannel(char *msg);			// #;Message
	void sendRemotePrivate(char *msg);		// :Name:Messsage
	void sendRemotePrivate(char *name, char *msg);

	void gotHelp(Player *p, Command *c);
	void gotCommand(Player *p, Command *c);
	void gotRemoteHelp(char *p, Command *c, Operator_Level l);
	void gotRemote(char *p, Command *c, Operator_Level l);
};


// The botlist contains every bot to ever be spawned of this type,
// some entries may no longer exist.

extern _linkedlist <botInfo> botlist;

botInfo *findBot(CALL_HANDLE handle);


#endif	// SPAWN_H
