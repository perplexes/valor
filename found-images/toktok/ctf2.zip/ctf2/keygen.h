/*
	Key Chain

	Collects random data to seed PRNG's during startup and at random intervals.
	Keys are created by iterating the PRNG and taking a secure message digest.

	catid(cat02e@fsu.edu)

	7/28/2003	Added to project from FakeTCP library
				Implemented random data collection in a separate thread

	Tabs: 4 spaces
*/

#ifndef KEYGEN_H
#define KEYGEN_H

#include "types.h"
#include "singleton.h"
#include "threadsafe.h"
#include "mt.h"

namespace cat
{
	//////// Constants ////////

	static const int COLLECTION_THREAD_PRIO = THREAD_PRIORITY_BELOW_NORMAL;
	//
	// Set priority for the random bit collection thread.
	//

	static const int MINIMUM_USAGE = 156;
	//
	// Minimum number of actual keys generated before a reseed is allowed
	//

	static const int MINIMUM_DELAY = 30000;	// ms
	//
	// Minimum number of milliseconds to wait between collecting random data
	//

	static const int MAXIMUM_DELAY = 60000;	// ms
	//
	// Maximum number of milliseconds to wait between collecting random data
	// Must not be less than MINIMUM_DELAY
	//


	//////// Key chain ////////

	class KeyChain : public Singleton<KeyChain>, Thread
	{
		RandomMT rnd;
		ManualEvent suicide;
		CriticalSection cs;
		uint32 iteration, usage;

		void reseedGenerator();

	protected:
		friend class Singleton<KeyChain>;

		KeyChain();

		DWORD run();

	public:
		~KeyChain();

		void getKey256(uint32 *key);	// uint32 key[8]
		void getKey512(uint32 *key);	// uint32 key[16]
		void getKey1024(uint32 *key);	// uint32 key[32]
	};
}

#endif // KEYGEN_H
