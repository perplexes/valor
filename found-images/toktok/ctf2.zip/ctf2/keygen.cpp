#include "keygen.h"
#include "sha2.h"
#include "timer.h"

#define _WIN32_WINNT 0x0400
#include <Wincrypt.h>
#pragma comment(lib, "advapi32.lib")

namespace cat
{
	//////// Ctors ////////

	KeyChain::KeyChain()
	{
		reseedGenerator();

		if (Thread::startThread())
			Thread::setPriority(COLLECTION_THREAD_PRIO);
	}

	KeyChain::~KeyChain()
	{
		suicide.set();

		Thread::waitOnThread();
	}


	//////// Internals ////////

	void KeyChain::reseedGenerator()
	{
		if (usage < MINIMUM_USAGE)
			return;

		HCRYPTPROV hCryptProv;

		cs.lock();

		uint32 *state = rnd.seed();

		*state = (uint32)getMicroseconds() ^ (iteration++);	// extra salt

		if (CryptAcquireContext(&hCryptProv, 0, 0, PROV_DSS, CRYPT_VERIFYCONTEXT))
		{
			CryptGenRandom(hCryptProv, VECTOR_SPACE * sizeof(uint32), (BYTE*)state);
			CryptReleaseContext(hCryptProv, 0);
		}

		cs.unlock();

		usage = 0;
	}

	DWORD KeyChain::run()
	{
		uint32 nextDelay = MINIMUM_DELAY;

		while (!suicide.waitOnEvent(nextDelay))
		{
			reseedGenerator();

			// randomize the next collection time
			nextDelay = MINIMUM_DELAY + rnd.random() % (MAXIMUM_DELAY - MINIMUM_DELAY + 1);
		}

		return 50;
	}


	//////// Exposed functions ////////

	void KeyChain::getKey256(uint32 *key)
	{
		cs.lock();

		rnd.random_nt_series(8, key);

		cs.unlock();

		++usage;

		DigestSHA256 md;

		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);
	}

	void KeyChain::getKey512(uint32 *key)
	{
		cs.lock();

		rnd.random_nt_series(16, key);

		cs.unlock();

		usage += 2;

		DigestSHA256 md;

		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);

		key += 8;

		md.beginDigest();
		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);
	}

	void KeyChain::getKey1024(uint32 *key)
	{
		cs.lock();

		rnd.random_nt_series(32, key);

		cs.unlock();

		usage += 4;

		DigestSHA256 md;

		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);

		key += 8;

		md.beginDigest();
		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);

		key += 8;

		md.beginDigest();
		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);

		key += 8;

		md.beginDigest();
		md.performDigest((char*)key, 32);
		MEMCOPY32(md.endDigest(), key, 8);
	}
}
