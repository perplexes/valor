/*
	Portable timer library
	
	by Catid (cat02e@fsu.edu)
	
	01/18/2003	Because, heck.  We all need one of these

	Tab: 4 spaces
 */

#ifndef TIMER_H
#define TIMER_H

#include "types.h"

#if defined(WIN32)

#if !defined(_INC_WINDOWS)
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif

#include <mmsystem.h>
#pragma comment (lib, "Winmm.lib")

#endif

namespace cat
{
	/*	getMicroseconds
		Returns state of a running counter, advancing once every microsecond.
		0.000001 seconds
		Best without special hardware

		getMilliseconds
		Returns state of a running counter, advancing once every millisecond.
		0.001 seconds
		Faster in Windows

		getCentiseconds
		Returns state of a running counter, advancing once every centisecond.
		0.01 seconds
		Faster in Windows/Macintosh

		getSeconds
		Returns state of a running counter, advancing once every second.
		1.00 seconds
		Faster in Windows/Macintosh
	 */

#if defined(WIN32)

	double getMicroseconds();
	uint32 getMilliseconds();

	inline uint32 getSeconds()
	{
		return GetTickCount() / 1000;
	}

	inline uint32 getCentiseconds()
	{
		return GetTickCount() / 10;
	}

	inline uint32 getMilliseconds()
	{
		return timeGetTime();
	}

#elif defined(__MAC)

	inline uint32 getCentiseconds();

#else

	uint32 getCentiseconds();

#endif

}

#endif // TIMER_H
