#include "threadsafe.h"

namespace cat
{
	//////// Thread ////////

	DWORD WINAPI threadProc(Thread *This)
	{
		return This->run();
	}

	Thread::Thread()
		: useCount(0)
	{
		hThread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)threadProc, this, CREATE_SUSPENDED, 0);
	}
	Thread::~Thread()
	{
		if (hThread) {
			CloseHandle(hThread);
			hThread = 0;
		}
	}

	bool Thread::startThread()
	{
		return (ResumeThread(hThread) != (DWORD)-1);
	}

	bool Thread::waitOnThread(DWORD timeout)
	{
		DWORD retCode = WaitForSingleObject(hThread, timeout);

		if (retCode == WAIT_TIMEOUT)
			return false;
		else if (retCode == WAIT_OBJECT_0)
			return true;
		else
			return false;	// error
	}

	void Thread::stopThread()
	{
		DWORD code;
		if (GetExitCodeThread(hThread, &code))
			ExitThread(code);
	}


	//////// Manual Reset Event ////////

	ManualEvent::ManualEvent(bool initiallySignaled)
	{
		hEvent = CreateEvent(0, false, initiallySignaled, 0);
	}

	ManualEvent::~ManualEvent()
	{
		CloseHandle(hEvent);
	}

	void ManualEvent::set()
	{
		SetEvent(hEvent);
	}

	void ManualEvent::reset()
	{
		ResetEvent(hEvent);
	}

	bool ManualEvent::waitOnEvent(DWORD timeout)
	{
		DWORD retCode = WaitForSingleObject(hEvent, timeout);

		if (retCode == WAIT_TIMEOUT)
			return false;
		else if (retCode == WAIT_OBJECT_0)
			return true;
		else
			return false;	// error
	}
}
