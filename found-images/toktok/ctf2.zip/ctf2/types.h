/*
	My portability library

	by Catid (cat02e@fsu.edu)

	7/27/2003	Added MEMADD32 for SHA2 algo
	7/8/2003	Added SWAP32 and MOD256
	7/3/2003	Added template triple, point->tuple
	6/15/2003	Added template rect, point
	3/30/2003	Added RO?8, RO?16 and ?int64
				Added MEMCOPY32 and MEMCLEAR32
	3/12/2003	Added GETWORD and GETDWORD
	01/16/2003	Formalized this library.

	Tab: 4 spaces
*/

#ifndef TYPES_H
#define TYPES_H

namespace cat
{
	// Basic types
#ifdef WIN32
	typedef unsigned __int8		uint8;
	typedef signed __int8		sint8;
	typedef unsigned __int16	uint16;
	typedef signed __int16		sint16;
	typedef unsigned __int32	uint32;
	typedef signed __int32		sint32;
	typedef unsigned __int64	uint64;
	typedef signed __int64		sint64;
#else	// system-dependent, fix for your arch
	typedef unsigned char		uint8;
	typedef signed char			sint8;
	typedef unsigned short		uint16;
	typedef signed short		sint16;
	typedef unsigned int		uint32;
	typedef signed int			sint32;
	typedef unsigned long long	uint64;
	typedef signed long long	sint64;
#endif

	template<class T> class rect
	{
	public:
		rect() : x(0), y(0), w(0), h(0) {}
		rect(T xx, T yy, T ww, T hh) : x(xx), y(yy), w(ww), h(hh) {}

		T x, y, w, h;
	};
}

// Byte-order swapping
#define BOSWAP16(n) ( ((n) << 8) | ((n) >> 8) ) /* only works for uint16 */
#define BOSWAP32(n) ( ((n) << 24) | (((n) & 0x00ff0000) >> 8) | (((n) & 0x0000ff00) << 8) | ((n) >> 24) ) /* only works for uint32 */

// Rotation
#define ROL8(n, r) ( ((n) << r) | ((n) >> (8 - r)) ) /* only works for uint8 */
#define ROR8(n, r) ( ((n) >> r) | ((n) << (8 - r)) ) /* only works for uint8 */
#define ROL16(n, r) ( ((n) << r) | ((n) >> (16 - r)) ) /* only works for uint16 */
#define ROR16(n, r) ( ((n) >> r) | ((n) << (16 - r)) ) /* only works for uint16 */
#define ROL32(n, r) ( ((n) << r) | ((n) >> (32 - r)) ) /* only works for uint32 */
#define ROR32(n, r) ( ((n) >> r) | ((n) << (32 - r)) ) /* only works for uint32 */
#define SWAP32(u) ( ((u) << 16) | ((u) >> 16) ) /* only works for uint32 */

// Type casting
#define GETWORD(ptr, offset) ( *(uint16*)((ptr) + (offset)) )
#define GETDWORD(ptr, offset) ( *(uint32*)((ptr) + (offset)) )
#define MOD256(n) ((n) & 255)

/*
	Clear memory that is allocated on a 32-bit boundary
	and has at least one block.

	Lotsa restrictions.  If you didn't write it, don't use it :-)
*/
#define MEMCLEAR32(ptr, len) { \
	register uint32 *__data = (uint32*)(ptr); /* pointer to data to clear */ \
	register sint32 __length = (len); /* number of 32-bit blocks */ \
\
	/* Duff's device */ \
	switch (__length % 8) \
	{ \
	case 0:	do {	*__data++ = 0; \
	case 7:			*__data++ = 0; \
	case 6:			*__data++ = 0; \
	case 5:			*__data++ = 0; \
	case 4:			*__data++ = 0; \
	case 3:			*__data++ = 0; \
	case 2:			*__data++ = 0; \
	case 1:			*__data++ = 0; \
					__length -= 8; \
			} while(__length > 0); \
	} \
}

/*
	Copy memory that is allocated on a 32-bit boundary
	and has at least one block.

	Lotsa restrictions.  If you didn't write it, don't use it :-)
*/
#define MEMCOPY32(src, dest, len) { \
	register uint32 *__dest = (uint32*)(dest); /* pointer to destination buffer */ \
	register uint32 *__src = (uint32*)(src); /* pointer to source buffer */ \
	register sint32 __length = (len); /* number of 32-bit blocks */ \
\
	/* Duff's device */ \
	switch (__length % 8) \
	{ \
	case 0:	do {	*__dest++ = *__src++; \
	case 7:			*__dest++ = *__src++; \
	case 6:			*__dest++ = *__src++; \
	case 5:			*__dest++ = *__src++; \
	case 4:			*__dest++ = *__src++; \
	case 3:			*__dest++ = *__src++; \
	case 2:			*__dest++ = *__src++; \
	case 1:			*__dest++ = *__src++; \
					__length -= 8; \
			} while(__length > 0); \
	} \
}

/*
	Add memory that is allocated on a 32-bit boundary
	and has at least one block to another such block.

	Lotsa restrictions.  If you didn't write it, don't use it :-)
*/
#define MEMADD32(src, dest, len) { \
	register uint32 *__dest = (uint32*)(dest); /* pointer to destination buffer */ \
	register uint32 *__src = (uint32*)(src); /* pointer to source buffer */ \
	register sint32 __length = (len); /* number of 32-bit blocks */ \
\
	/* Duff's device */ \
	switch (__length % 8) \
	{ \
	case 0:	do {	*__dest++ += *__src++; \
	case 7:			*__dest++ += *__src++; \
	case 6:			*__dest++ += *__src++; \
	case 5:			*__dest++ += *__src++; \
	case 4:			*__dest++ += *__src++; \
	case 3:			*__dest++ += *__src++; \
	case 2:			*__dest++ += *__src++; \
	case 1:			*__dest++ += *__src++; \
					__length -= 8; \
			} while(__length > 0); \
	} \
}

/*
	Safe null-terminated string -> char buffer copy
*/
#define STRNCPY(dest, src, size) { \
	strncpy(dest, src, size); \
	dest[size-1] = 0; \
}

#endif // TYPES_H
