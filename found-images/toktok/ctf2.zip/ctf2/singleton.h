/*
	Templated singleton class

	instantiate on demand
	destroy on termination
	thread-safe

	catid(cat02e@fsu.edu)

	6/16/2003	Began writing
*/

#ifndef SINGLETON_H
#define SINGLETON_H

#include "types.h"
#include "threadsafe.h"

namespace cat
{
	template<class T> class Singleton
		/*
			Usage:

			class T : public Singleton<T>
			{
				...

			protected:
				friend class Singleton<T>;

				T();

				// no copies
				T(const T &);
				T &operator=(const T &);

				...
			};

			Instantiate on demand with MySingleton::instance()
		*/
	{
		static T *pInstance;
		static SpeedLock cs;

		// no copies
		Singleton(const Singleton &cp);
		Singleton &operator=(const Singleton &cp); 

	protected:
		Singleton<T>() {
		}

	public:
		static inline T *instance()
		{
			if (pInstance) return pInstance;

			cs.lock();

			if (pInstance) {
				cs.unlock();

				return pInstance;
			}

			pInstance = new T;

			cs.unlock();

			return pInstance;
		}

		static inline void destroyInstance()
		{
			if (!pInstance) return;

			cs.lock();

			if (!pInstance) {
				cs.unlock();

				return;
			}

			delete pInstance;

			cs.unlock();
		}
	};

	template<class T> T *Singleton<T>::pInstance = 0;
	template<class T> SpeedLock Singleton<T>::cs;
}

#endif // SINGLETON_H
