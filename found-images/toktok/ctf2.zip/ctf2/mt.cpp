#include "mt.h"
#include "sha2.h"

#define HIBIT(u)		((u) & 0x80000000)		/* Mask all but highest-bit of u */
#define LOBIT(u)		((u) & 0x00000001)		/* Mask all but lowest-bit of u */
#define LOBITS(u)		((u) & 0x00000001)		/* Mask all but lowest-bit of u */
#define MIXBITS(u, v)	(HIBIT(u) | LOBITS(v))	/* Mix bits of two registers */

#define TEMPER32(y) \
	(y) ^= ((y) >> 11); \
	(y) ^= ((y) << 7) & 0x9d2c5680; \
	(y) ^= ((y) << 15) & 0xefc60000; \
	(y) ^= ((y) >> 18);

namespace cat
{
	const uint32 PERIOD_PARAM = 397;
	const uint32 K = 0x9908b0df;
	const uint32 MAGIC_0[2] = {0, K};

	RandomMT::RandomMT()
	{
		left = -1;
		MEMCLEAR32(state, sizeof state / 4);
		next = 0;
	}

	RandomMT::~RandomMT()
	{
		left = -1;
		MEMCLEAR32(state, sizeof state / 4);
		next = 0;
	}

	void RandomMT::reload()
	{	// Regenerate buffer
		uint32 ii, jj;

		for (ii = 0; ii < VECTOR_SPACE - PERIOD_PARAM; ++ii)
		{
			jj = MIXBITS(state[ii], state[ii+1]);
			state[ii] = state[ii + PERIOD_PARAM] ^ (jj >> 1) ^ MAGIC_0[LOBIT(jj)];
		}

		for (; ii < VECTOR_SPACE; ++ii)
		{
			jj = MIXBITS(state[ii], state[ii+1]);
			state[ii] = state[ii + PERIOD_PARAM - VECTOR_SPACE] ^ (jj >> 1) ^ MAGIC_0[LOBIT(jj)];
		}

		left = VECTOR_SPACE - 1;
		next = state + 1;
	}

	void RandomMT::seed(uint32 seed)
	{	// Seed the generator
		register uint32 *s = state;
		register uint32 x = seed;
		register sint32 ii;

		left = 0;
		*s++ = x;

		for (ii = VECTOR_SPACE; --ii; *s++ = (x *= 69069U));
	}

	void RandomMT::seed(char *buf, uint32 len)
	{	// Seed the generator
		DigestSHA256 md1, md2;
		uint32 *reg, *s = state, completed = 0;

		// first round takes in the buffer
		md1.beginDigest();
		md1.performDigest(buf, len);
		reg = md1.endDigest();

		MEMCOPY32(reg, s, 8);
		s += 8;

		// following rounds are chained
		md2.beginDigest();
		md2.performDigest((char*)reg, 32);
		reg = md2.endDigest();

		MEMCOPY32(reg, s, 8);
		s += 8;
		
		completed += 16;

		while (completed < VECTOR_SPACE)
		{
			md1.beginDigest();
			md1.performDigest((char*)reg, 32);
			reg = md1.endDigest();

			MEMCOPY32(reg, s, 8);
			s += 8;

			md2.beginDigest();
			md2.performDigest((char*)reg, 32);
			reg = md2.endDigest();

			MEMCOPY32(reg, s, 8);
			s += 8;

			completed += 16;
		}

		left = VECTOR_SPACE;
		next = state;
	}

	uint32 *RandomMT::seed()
	{
		return state;

		left = VECTOR_SPACE;
		next = state;
	}

	bool RandomMT::random_bool()
	{
		uint32 n = random();

		return (n & (1 << ((n & 15) + 5))) == 0;
	}

	uint32 RandomMT::random(sint32 start, sint32 end)
	{
		if (end - start <= 0) return 0;

		uint32 range = uint32(end - start + 1);

		uint32 ii, mask = 0xffffffff, ctr = 0x80000000;

		--range;
		do {
			if (range & ctr)
				break;

			mask ^= ctr;
		} while (ctr >>= 1);
		++range;

		do ii = random_nt() & mask; while(ii >= range);

		return ii + start;
	}

	uint32 RandomMT::random()
	{	// Get next in sequence
		register uint32 jj;

		if (--left < 0)
			reload();

		// Tempering
		jj = *next++;
		TEMPER32(jj);

		return jj;
	}

	uint32 RandomMT::random_nt()
	{	// Get next in sequence
		if (--left < 0)
			reload();

		return *next++;
	}

	uint32 RandomMT::get(uint16 ii)
	{	// Get sequence at ii
		register uint32 jj = state[ii];

		// Tempering
		TEMPER32(jj);

		return jj;
	}

	void RandomMT::random_nt_series(uint32 len, uint32 *buf)
	{
		while (len--)
		{
			*buf++ = random_nt();
		}
	}
}
