#include "flagmover.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <fstream>
using namespace std;

#define BUFFER_LEN 256

static char bitmap[BUFFER_LEN];
static char path[BUFFER_LEN];


//////// Flag matrix ////////

bool FlagMatrix::BadFlagGrid(int x, int y)
{
	if (badFile) return false;

	if (x < 0)	return false;
	if (y < 0)	return false;
	if (x >= MATRIX_DIAMETER)	return false;
	if (y >= MATRIX_DIAMETER)	return false;

	BYTE *b = map;

	if (bottomUp)
	{
		b += (1024 * (1023 - y)) + x;
	}
	else
	{
		b += 1024 * y + x;
	}

	return (*b == 255);
}

bool LoadMatrix(FlagMatrix &matrix, const char *fileName)
{
	matrix.badFile = true;

	if (*fileName == 0) return false;

	// Load bitmap
	ifstream file(fileName, ios::binary);
	if (!file) return false;

	// Read file header
	BITMAPFILEHEADER fhdr;
	file.read((char*)&fhdr, sizeof(fhdr));

	// Read info header
	BITMAPINFOHEADER ihdr;
	file.read((char*)&ihdr, sizeof(ihdr));

	// Must be uncompressed
	if (ihdr.biCompression != BI_RGB)
		return false;

	// Must be 8-bit
	if (ihdr.biBitCount != 8)
		return false;

	// Must have width of 1024
	if (ihdr.biWidth != 1024)
		return false;

	// Must have height of 1024
	matrix.bottomUp = (ihdr.biHeight > 0);

	if (matrix.bottomUp)
	{
		if (ihdr.biHeight != 1024)
			return false;
	}
	else
	{
		if (ihdr.biHeight != -1024)
			return false;
	}

	// Seek to bitmap bytes
	int ClrUsed = ihdr.biClrUsed;
	if (ClrUsed == 0) ClrUsed = 256;

	file.seekg(ClrUsed * sizeof(RGBQUAD), ios::cur);

	// Read bitmap directly into map matrix
	file.read((char*)matrix.map, MATRIX_LINEAR);

	matrix.badFile = false;

	return true;
}
