/*
	Capture the flag settings and algorithms

	catid(cat02e@fsu.edu)

	Sept 10, 2003	Began writing

	Tabs: 4 spaces
*/

#ifndef CTF_H
#define CTF_H

#include "types.h"
#include "../player.h"

#include "flagmover.h"

namespace cat
{
	const uint16 NO_TEAM_OWNER = 0xffff;
	const uint16 NO_LOCALE = 0xffff;

	enum FlagState
	{
		STATE_Carried,	// flag is believed to be carried
		STATE_Dropping,	// we expect to see it on the map with the next relevant flag update
		STATE_Dropped,	// should be on the map
	};

	struct TeamFlagInfo
	{
		FlagState state;	// initially STATE_Dropping

		// STATE_Dropped
		uint16 xTile, yTile;	// initially (NO_LOCALE, NO_LOCALE)
		uint16 team;			// team color for flag

		// STATE_Carried
		Player *carrier;	// initially 0
		bool limbo;	// initially false, only true if dropped after enemy flagger death

		// Settings from CTF2.INI [Flags] section
		uint16 xAtRest, yAtRest;

		// Score
		uint16 goals;
	};

	const uint16 MAX_TEAMFLAGS = 8;
	const uint16 MAX_RULES = 8;

	struct CTFInfo
	{
		uint16 numTeamflags;	// should never be higher than MAX_TEAMFLAGS

		TeamFlagInfo teamflags[MAX_TEAMFLAGS];	// index = team # and flag #

		// Settings from CTF2.INI [Game] section
		uint16 goalRadius;

		uint16 minimumGap, maximumGap;
		uint16 minimumGoals, maximumGoals;

		bool teamScramble, mustControl, limboFlags;

		uint16 newGameDelay;

		uint16 minimumPlayers;

		uint16 flaggerCapturePoints;

		uint16 teamVictoryPoints;

		bool useServerJackpot;

		bool betweenGames;

		String ruleText[MAX_RULES];

		uint16 periodicRewardInterval, periodicRewardPoints;

		uint16 teamKillLimit;

		String bitmapFile;

		FlagMatrix matrix;
	};

	void resetFlagInfo(CTFInfo &ctf);

	static const char *INI_FILE = "CTF2.INI";

	void readCTFInfo(CTFInfo &ctf, char *arena);
	void writeCTFInfo(CTFInfo &ctf, char *arena);

	/*
	case EVENT_FlagGrab:
		Given player, flag x, y, ident, team
	case EVENT_FlagDrop:
		Given flag id
	case EVENT_FlagMove:
		Given flag x, y, ident, team
	case EVENT_FlagVictory:
		Given team and points
	case EVENT_FlagGameReset:
	case EVENT_FlagReward:
		Given team and points
	*/
}

#endif // CTF_H
