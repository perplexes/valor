#include "timer.h"

namespace cat
{
	//////// Timers ////////

	#if defined(WIN32)

		// Windows version

		double getMicroseconds()
		{
			LARGE_INTEGER tim, freq; // 64-bit! ieee
			double usec;

			QueryPerformanceCounter(&tim);
			QueryPerformanceFrequency(&freq);
			usec = (static_cast<double>(tim.QuadPart) * 1000000.0) / static_cast<double>(freq.QuadPart);

			return usec;
		}

	#elif defined(__MAC)

		// Macintosh version (to come)

	#else

		// UNIX version

		#include <sys/time.h>

		static struct timeval cateq_v;
		static struct timezone cateq_z;

		double getMicroseconds()
		{
			gettimeofday(&cateq_v, &cateq_z);

			return 1000000.0 * static_cast<double>(cateq_v.tv_sec) + static_cast<double>(cateq_v.tv_usec);
		}

		uint32 getMilliseconds()
		{
			gettimeofday(&cateq_v, &cateq_z);

			return static_cast<uint32>(1000.0 * static_cast<double>(cateq_v.tv_sec) + static_cast<double>(cateq_v.tv_usec) / 1000.0);
		}

		uint32 getCentiseconds()
		{
			gettimeofday(&cateq_v, &cateq_z);

			return static_cast<uint32>(100.0 * static_cast<double>(cateq_v.tv_sec) + static_cast<double>(cateq_v.tv_usec) / 10000.0);
		}

	#endif
}
