/*
	Classes related to multi-threading

	catid(cat02e@fsu.edu)

	6/16/2003	Began writing

	Not compatible with C run-time library
	Tabs: 4 spaces
*/

#ifndef THREADSAFE_H
#define THREADSAFE_H

#if !defined(_INC_WINDOWS)
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#endif

namespace cat
{
	//////// Thin CRITICAL_SECTION wrapper ////////

	class CriticalSection
	{
		CRITICAL_SECTION cs;

	public:
		inline CriticalSection() { InitializeCriticalSection(&cs); }
		virtual inline ~CriticalSection() { DeleteCriticalSection(&cs); }

		inline void lock() { EnterCriticalSection(&cs); }
		inline void unlock() { LeaveCriticalSection(&cs); }

		inline CRITICAL_SECTION getCS() { return cs; }
	};


	//////// Thread ////////

	class Thread
	{
		int useCount;
		HANDLE hThread;

		friend static DWORD WINAPI threadProc(Thread *This);

		// no copies
		Thread(const Thread &cp);
		Thread &operator=(const Thread &cp);

	protected:
		// must implement the thread's procedure
		virtual DWORD run() = 0;

	public:
		Thread();
		virtual ~Thread();

		inline HANDLE getHandle() const { return hThread; }

		void setPriority(int nPriority) {
			SetThreadPriority(hThread, nPriority);
		}

		bool startThread();								// start thread
		bool waitOnThread(DWORD timeout = INFINITE);	// wait for thread to stop
		void stopThread();								// forcibly stop thread
	};


	//////// Manual Reset Event ////////

	class ManualEvent
	{
		HANDLE hEvent;

	protected:
		// no copies
		ManualEvent(const ManualEvent &cp);
		ManualEvent &operator=(const ManualEvent &cp);

	public:
		ManualEvent(bool initiallySignaled = false);
		~ManualEvent();

		inline HANDLE getHandle() const { return hEvent; }

		void set();
		void reset();

		bool waitOnEvent(DWORD timeout = INFINITE);	// returns true if event was set
	};


	//////// Speedy EVENT thread sync ////////

	class SpeedLock
	{
		HANDLE hEvent;

	protected:
		// no copies
		SpeedLock(const SpeedLock &cp);
		SpeedLock &operator=(const SpeedLock &cp);

	public:
		inline SpeedLock() { hEvent = CreateEvent(0, false, true, 0); }
		inline ~SpeedLock() { CloseHandle(hEvent); }

		// do not call recursively
		inline void lock() { WaitForSingleObject(hEvent, INFINITE); }
		inline void unlock() { SetEvent(hEvent); }
	};
}

#endif // THREADSAFE_H
