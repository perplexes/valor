/*
	Sept 12		Copied from flagmover plugin
*/

#ifndef FLAGMOVER_H
#define FLAGMOVER_H

#define MATRIX_DIAMETER	1024
#define MATRIX_LINEAR	(MATRIX_DIAMETER * MATRIX_DIAMETER)

#include "..\datatypes.h"

struct FlagMatrix
{
	BYTE map[MATRIX_LINEAR];

	bool bottomUp;
	bool badFile;

	bool BadFlagGrid(int x, int y);
};

bool LoadMatrix(FlagMatrix &matrix, const char *fileName);

#endif	// FLAGMOVER_H
