#include "ctf.h"

#include "spawn.h"
#include "../algorithms.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

namespace cat
{
	const uint16 BUFFER_LEN = 256;

	void resetFlagInfo(CTFInfo &ctf)
	{
		uint16 numTeamFlags = ctf.numTeamflags;
		TeamFlagInfo *info = ctf.teamflags;

		while (numTeamFlags--)
		{
			// in-game stuff
			info->state = STATE_Dropping;
			info->carrier = 0;
			info->team = NO_TEAM_OWNER;
			info->xTile = NO_LOCALE;
			info->yTile = NO_LOCALE;
			info->goals = 0;
			info->limbo = false;

			++info;
		}

		ctf.betweenGames = false;
	}

	void readCTFInfo(CTFInfo &ctf, char *arena)
	{
		char buffer[BUFFER_LEN+1];
		char path[BUFFER_LEN+1];

		GetCurrentDirectory(BUFFER_LEN - 12, path);
		strcat(path, "\\");
		strcat(path, INI_FILE);

		if (!*arena || isNumeric(arena))
			arena = "Public";
		else
		{
			GetPrivateProfileString(arena, "Enabled", "0", buffer, BUFFER_LEN, path);
			int enabled = getInteger(buffer, 10);

			if (!enabled)
				arena = "Public";
		}

		uint16 ii = 0;

		while (ii < MAX_TEAMFLAGS)
		{
			String s;
			s += "Goal";
			s += ii;
			GetPrivateProfileString(arena, s.msg, "", buffer, BUFFER_LEN, path);

			if (!*buffer)
				break;

			TeamFlagInfo *info = ctf.teamflags + ii;

			// INI settings
			s = buffer;

			info->xAtRest = s.split(',').toInteger();
			info->yAtRest = s.toInteger();

			++ii;
		}

		ctf.numTeamflags = ii;

		for (ii = 0; ii < MAX_RULES; ++ii)
		{
			String s;
			s += "Rule";
			s += ii;
			GetPrivateProfileString(arena, s.msg, "", buffer, BUFFER_LEN, path);

			ctf.ruleText[ii] = buffer;
		}

		GetPrivateProfileString(arena, "GoalRadius", "7", buffer, BUFFER_LEN, path);
		ctf.goalRadius = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "MinimumGoals", "3", buffer, BUFFER_LEN, path);
		ctf.minimumGoals = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "MaximumGoals", "0", buffer, BUFFER_LEN, path);
		ctf.maximumGoals = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "MinimumGap", "0", buffer, BUFFER_LEN, path);
		ctf.minimumGap = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "MaximumGap", "0", buffer, BUFFER_LEN, path);
		ctf.maximumGap = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "TeamScramble", "1", buffer, BUFFER_LEN, path);
		ctf.teamScramble = getInteger(buffer, 10) == 1;

		GetPrivateProfileString(arena, "MustControl", "1", buffer, BUFFER_LEN, path);
		ctf.mustControl = getInteger(buffer, 10) == 1;

		GetPrivateProfileString(arena, "LimboFlags", "1", buffer, BUFFER_LEN, path);
		ctf.limboFlags = getInteger(buffer, 10) == 1;

		GetPrivateProfileString(arena, "NewGameDelay", "10", buffer, BUFFER_LEN, path);
		ctf.newGameDelay = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "MinimumPlayers", "3", buffer, BUFFER_LEN, path);
		ctf.minimumPlayers = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "FlaggerCapturePoints", "50", buffer, BUFFER_LEN, path);
		ctf.flaggerCapturePoints = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "TeamVictoryPoints", "250", buffer, BUFFER_LEN, path);
		ctf.teamVictoryPoints = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "UseServerJackpot", "1", buffer, BUFFER_LEN, path);
		ctf.useServerJackpot = getInteger(buffer, 10) == 1;

		GetPrivateProfileString(arena, "PeriodicRewardInterval", "90", buffer, BUFFER_LEN, path);
		ctf.periodicRewardInterval = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "PeriodicRewardPoints", "50", buffer, BUFFER_LEN, path);
		ctf.periodicRewardPoints = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "TeamKillLimit", "3", buffer, BUFFER_LEN, path);
		ctf.teamKillLimit = getInteger(buffer, 10);

		GetPrivateProfileString(arena, "BitmapFile", "", buffer, BUFFER_LEN, path);
		ctf.bitmapFile = buffer;

		resetFlagInfo(ctf);

		if (ctf.limboFlags)
		{
			LoadMatrix(ctf.matrix, ctf.bitmapFile.msg);
		}
	}

	void writeCTFInfo(CTFInfo &ctf, char *arena)
	{
		char path[BUFFER_LEN+1];

		GetCurrentDirectory(BUFFER_LEN - 12, path);
		strcat(path, "\\");
		strcat(path, INI_FILE);

		if (!*arena || isNumeric(arena))
			arena = "Public";

		WritePrivateProfileString(arena, "Enabled", "1", path);

		uint16 ii = 0;

		while (ii < MAX_TEAMFLAGS)
		{
			TeamFlagInfo *info = ctf.teamflags + ii;

			String t;
			t += "Goal";
			t += ii;

			if (ii >= ctf.numTeamflags)
			{
				WritePrivateProfileString(arena, t.msg, "", path);
			}
			else
			{
				String s;
				s += info->xAtRest;
				s += ", ";
				s += info->yAtRest;

				WritePrivateProfileString(arena, t.msg, s.msg, path);
			}

			++ii;
		}

		for (ii = 0; ii < MAX_RULES; ++ii)
		{
			String s;
			s += "Rule";
			s += ii;

			WritePrivateProfileString(arena, s.msg, ctf.ruleText[ii].msg, path);
		}

		WritePrivateProfileString(arena, "GoalRadius", String(ctf.goalRadius).msg, path);
		WritePrivateProfileString(arena, "MinimumGoals", String(ctf.minimumGoals).msg, path);
		WritePrivateProfileString(arena, "MaximumGoals", String(ctf.maximumGoals).msg, path);
		WritePrivateProfileString(arena, "MinimumGap", String(ctf.minimumGap).msg, path);
		WritePrivateProfileString(arena, "MaximumGap", String(ctf.maximumGap).msg, path);
		WritePrivateProfileString(arena, "TeamScramble", String(ctf.teamScramble).msg, path);
		WritePrivateProfileString(arena, "MustControl", String(ctf.mustControl).msg, path);
		WritePrivateProfileString(arena, "LimboFlags", String(ctf.limboFlags).msg, path);
		WritePrivateProfileString(arena, "NewGameDelay", String(ctf.newGameDelay).msg, path);
		WritePrivateProfileString(arena, "MinimumPlayers", String(ctf.minimumPlayers).msg, path);
		WritePrivateProfileString(arena, "FlaggerCapturePoints", String(ctf.flaggerCapturePoints).msg, path);
		WritePrivateProfileString(arena, "TeamVictoryPoints", String(ctf.teamVictoryPoints).msg, path);
		WritePrivateProfileString(arena, "UseServerJackpot", String(ctf.useServerJackpot).msg, path);
		WritePrivateProfileString(arena, "PeriodicRewardInterval", String(ctf.periodicRewardInterval).msg, path);
		WritePrivateProfileString(arena, "PeriodicRewardPoints", String(ctf.periodicRewardPoints).msg, path);
		WritePrivateProfileString(arena, "TeamKillLimit", String(ctf.teamKillLimit).msg, path);
		WritePrivateProfileString(arena, "BitmapFile", String(ctf.bitmapFile).msg, path);
	}
}
