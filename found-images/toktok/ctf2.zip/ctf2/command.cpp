#include "spawn.h"

#include "..\algorithms.h"


void botInfo::gotHelp(Player *p, Command *c)
{
	// List commands

	if (!*c->final)
	{
		switch (p->access)
		{
		case OP_Duke:
		case OP_Baron:
		case OP_King:
		case OP_Emperor:
		case OP_RockStar:
		case OP_Q:
		case OP_God:
		case OP_Owner:
			{	// Owner-level commands
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus !ctfGreet !tkCheck !TeamKillLimit !Recycle");
				sendPrivate(p, "CTF[Game]: !MaximumGap !MinimumGap !MaximumGoals !MinimumGoals !TeamScramble !NewGameDelay !MustControl !LimboFlags");
				sendPrivate(p, "CTF[Points]: !MinimumPlayers !FlaggerCapturePoints !TeamVictoryPoints !UseServerJackpot !PeriodicRewardInterval !PeriodicRewardPoints");
			}
			break;
		case OP_SysOp:
			{	// SysOp-level commands
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus !ctfGreet !tkCheck !TeamKillLimit");
				sendPrivate(p, "CTF[Game]: !MaximumGap !MinimumGap !MaximumGoals !MinimumGoals !TeamScramble !NewGameDelay !MustControl !LimboFlags");
				sendPrivate(p, "CTF[Points]: !MinimumPlayers !FlaggerCapturePoints !TeamVictoryPoints !UseServerJackpot !PeriodicRewardInterval !PeriodicRewardPoints");
			}
			break;
		case OP_SuperModerator:
		case OP_Moderator:
			{	// Moderator-level commands
				// SuperModerator-level commands
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus");
			}
			break;
		case OP_Limited:
			{	// Limited-level commands
			}
		case OP_Player:
			{	// Player-level commands
				sendPrivate(p, "CTF: !rules (display game rules)");
				sendPrivate(p, "CTF: !score (display game score)");
			}
		}

		return;
	}

	// Specific command help

	switch (p->access)
	{
	case OP_Duke:
	case OP_Baron:
	case OP_King:
	case OP_Emperor:
	case OP_RockStar:
	case OP_Q:
	case OP_God:
	case OP_Owner:
		{	// Owner-level commands
			if (c->checkParam("owner") || c->checkParam("all"))
			{
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus !ctfGreet !tkCheck !TeamKillLimit !Recycle");
				sendPrivate(p, "CTF[Game]: !MaximumGap !MinimumGap !MaximumGoals !MinimumGoals !TeamScramble !NewGameDelay !MustControl !LimboFlags");
				sendPrivate(p, "CTF[Points]: !MinimumPlayers !FlaggerCapturePoints !TeamVictoryPoints !UseServerJackpot !PeriodicRewardInterval !PeriodicRewardPoints");
			}
			else if (c->checkParam("recycle"))
			{
				sendPrivate(p, "!recycle (Re-read INI and restart the flag game)");
			}
		}
	case OP_SysOp:
		{	// SysOp-level commands
			if (c->checkParam("sop") || c->checkParam("all"))
			{
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus !ctfGreet !tkCheck !TeamKillLimit");
				sendPrivate(p, "CTF[Game]: !MaximumGap !MinimumGap !MaximumGoals !MinimumGoals !TeamScramble !NewGameDelay !MustControl !LimboFlags");
				sendPrivate(p, "CTF[Points]: !MinimumPlayers !FlaggerCapturePoints !TeamVictoryPoints !UseServerJackpot !PeriodicRewardInterval !PeriodicRewardPoints");
			}
			else if (c->checkParam("ctfgreet"))
			{
				sendPrivate(p, "!ctfgreet [on/off] (Score greeting: on/off/just checking!)");
			}
			else if (c->checkParam("tkcheck"))
			{
				sendPrivate(p, "!tkcheck [on/off] (TK checking: on/off/just checking!)");
			}
			else if (c->checkParam("teamkilllimit"))
			{
				sendPrivate(p, "!teamkilllimit [#] (If you specify a number, this is the number of team kills within 10 minutes that leads to a 10-minute ban)");
			}
		}
	case OP_SuperModerator:
		{	// SuperModerator-level commands
			if (c->checkParam("smod") || c->checkParam("all"))
			{
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus");
			}
		}
	case OP_Moderator:
		{	// Moderator-level commands
			if (c->checkParam("mod") || c->checkParam("all"))
			{
				sendPrivate(p, "CTF: !StartCTF !StopCTF !ctfStatus");
			}
			else if (c->checkParam("startctf"))
			{
				sendPrivate(p, "!startctf (Start CTF game. Will reset score, etc)");
			}
			else if (c->checkParam("stopctf"))
			{
				sendPrivate(p, "!stopctf (Stop CTF game. Will reset score)");
			}
			else if (c->checkParam("ctfstatus"))
			{
				sendPrivate(p, "!ctfstatus (Display debug info)");
			}
		}
	case OP_Limited:
		{	// Limited-level commands
		}
	case OP_Player:
		{	// Player-level commands
			if (c->checkParam("about"))
			{
				sendPrivate(p, "!about (query me about my function)");
			}
		}
	}
}

void botInfo::gotCommand(Player *p, Command *c)
{
	if (!p) return;
	if (!c) return;

	switch (p->access)
	{
	case OP_Duke:
	case OP_Baron:
	case OP_King:
	case OP_Emperor:
	case OP_RockStar:
	case OP_Q:
	case OP_God:
	case OP_Owner:
		{	// Owner-level commands
			if (c->check("recycle"))
			{
				readCTFInfo(ctf, arena);

				enabled = true;
				awardNextSeenJackpot = false;
				gameStartTime = GetTickCount();

				sendPublic("*flagreset");

				sendPrivate(p, "Recycling CTF game... You should immediately see an arena message.");
				sendPublic(SND_TrebleBeep, "*arena Capture the Flag restarting with new settings.");
			}
		}
	case OP_SysOp:
		{	// SysOp-level commands
			if (c->check("ctfgreet"))
			{
				if (c->checkParam("on"))
					greeter = true;
				else if (c->checkParam("off"))
					greeter = false;

				if (greeter)
					sendPrivate(p, "Greeter is ON");
				else
					sendPrivate(p, "Greeter is OFF");
			}
			else if (c->check("tkcheck"))
			{
				if (c->checkParam("on"))
					tkchecker = true;
				else if (c->checkParam("off"))
					tkchecker = false;

				if (tkchecker)
					sendPrivate(p, "TK Checker is ON");
				else
					sendPrivate(p, "TK Checker is OFF");
			}
			else if (c->check("minimumgap"))
			{
				if (isNumeric(c->final))
				{
					ctf.minimumGap = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Minimum number of goals advantage to win: " + String(ctf.minimumGap));
			}
			else if (c->check("maximumgap"))
			{
				if (isNumeric(c->final))
				{
					ctf.maximumGap = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Goals advantage for instant win: " + String(ctf.maximumGap));
			}
			else if (c->check("minimumgoals"))
			{
				if (isNumeric(c->final))
				{
					ctf.minimumGoals = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Minimum number of goals to win: " + String(ctf.minimumGoals));
			}
			else if (c->check("maximumgoals"))
			{
				if (isNumeric(c->final))
				{
					ctf.maximumGoals = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of goals for instant win: " + String(ctf.maximumGoals));
			}
			else if (c->check("teamscramble"))
			{
				if (isNumeric(c->final))
				{
					ctf.teamScramble = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Send mass-Warp! after flag game: " + String(ctf.teamScramble));
			}
			else if (c->check("newgamedelay"))
			{
				if (isNumeric(c->final))
				{
					ctf.newGameDelay = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Seconds before new game starts: " + String(ctf.newGameDelay));
			}
			else if (c->check("mustcontrol"))
			{
				if (isNumeric(c->final))
				{
					ctf.mustControl = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Team must control flag to make a goal: " + String(ctf.mustControl));
			}
			else if (c->check("limboflags"))
			{
				if (isNumeric(c->final))
				{
					ctf.limboFlags = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "When flaggers drop their flag, will flag stick around in limbo until someone grabs it: " + String(ctf.limboFlags));
			}
			else if (c->check("minimumplayers"))
			{
				if (isNumeric(c->final))
				{
					ctf.minimumPlayers = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Minimum number of players for any points to be awarded: " + String(ctf.minimumPlayers));
			}
			else if (c->check("flaggercapturepoints"))
			{
				if (isNumeric(c->final))
				{
					ctf.flaggerCapturePoints = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of points awarded to flaggers for making a single goal: " + String(ctf.flaggerCapturePoints));
			}
			else if (c->check("teamvictorypoints"))
			{
				if (isNumeric(c->final))
				{
					ctf.teamVictoryPoints = getInteger(c->final, 10);
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of points awarded to winning team: " + String(ctf.teamVictoryPoints));
			}
			else if (c->check("useserverjackpot"))
			{
				if (isNumeric(c->final))
				{
					ctf.useServerJackpot = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Add server ?jackpot points to flag reward: " + String(ctf.useServerJackpot));
			}
			else if (c->check("periodicrewardinterval"))
			{
				if (isNumeric(c->final))
				{
					ctf.periodicRewardInterval = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of seconds between periodic rewards: " + String(ctf.periodicRewardInterval));
			}
			else if (c->check("periodicrewardpoints"))
			{
				if (isNumeric(c->final))
				{
					ctf.periodicRewardPoints = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of points to prize to each person on rewarded team: " + String(ctf.periodicRewardPoints));
			}
			else if (c->check("teamkilllimit"))
			{
				if (isNumeric(c->final))
				{
					ctf.teamKillLimit = getInteger(c->final, 10) == 1;
					writeCTFInfo(ctf, arena);
				}

				sendPrivate(p, "Number of kills in 10 minutes leading to 10 minute ban: " + String(ctf.teamKillLimit));
			}
		}
	case OP_SuperModerator:
		{	// SuperModerator-level commands
			if (c->check("version"))
			{
				sendPrivate(p, "[name:ctf2.dll] [maker:cat02e@fsu.edu] [build:3]");
			}
		}
	case OP_Moderator:
		{	// Moderator-level commands
			if (c->check("startctf"))
			{
				if (enabled)
				{
					sendPrivate(p, "CTF is already started");
					break;
				}

				enabled = true;
				awardNextSeenJackpot = false;
				gameStartTime = GetTickCount();

				sendPublic("*flagreset");
				resetFlagInfo(ctf);

				sendPrivate(p, "Starting CTF game... You should immediately see an arena message.");
				sendPublic(SND_TrebleBeep, "*arena Capture the Flag restarted.");
			}
			else if (c->check("stopctf"))
			{
				if (!enabled)
				{
					sendPrivate(p, "CTF is already stopped");
					break;
				}

				enabled = false;
				awardNextSeenJackpot = false;

				sendPrivate(p, "Stopping CTF game... You should immediately see an arena message.");
				sendPublic(SND_BassBeep, "*arena Capture the Flag stopped.");
			}
			else if (c->check("ctfstatus"))
			{
				TeamFlagInfo *info = ctf.teamflags;
				uint16 ii = 0, numTeamFlags = ctf.numTeamflags;

				while (numTeamFlags--)
				{
					String s;

					s += "(team/flag #";
					s += ii;
					s += "): ";

					switch (info->state)
					{
					case STATE_Dropping:
						s += "[DROPPING] ";
						break;
					case STATE_Dropped:
						s += "[DROPPED] ";
						break;
					case STATE_Carried:
						s += "[CARRIED] ";
						break;
					}

					s += "carrier:";
					if (info->carrier)
						s += info->carrier->name;
					else
						s += "::NULL::";

					s += " teamcolor:";
					if (info->team == NO_TEAM_OWNER)
						s += "n/a";
					else
						s += info->team;
					s += " loc:(";
					if (info->xTile == NO_LOCALE)
						s += "n/a";
					else
						s += info->xTile;
					s += ", ";
					if (info->yTile == NO_LOCALE)
						s += "n/a";
					else
						s += info->yTile;
					s += ")";

					sendPrivate(p, s);

					++ii;
					++info;
				}
			}
		}
	case OP_Limited:
		{	// Limited-level commands
		}
	case OP_Player:
		{	// Player-level commands
			if (c->check("rules"))
			{
				for (uint16 ii = 0; ii < MAX_RULES; ++ii)
				{
					String s = ctf.ruleText[ii];

					if (!s.IsEmpty())
						sendPrivate(p, s);
				}
			}
			else if (c->check("score"))
			{
				if (!enabled)
				{
					sendPrivate(p, "CTF game has not started.");
					break;
				}

				String s;

				if (ctf.betweenGames)
				{
					s += "Score from last game:";
				}
				else
				{
					s += "Score:";
				}

				for (uint16 ii = 0; ii < ctf.numTeamflags; ++ii)
				{
					s += "  Team ";
					s += ii;
					s += ":(";
					s += ctf.teamflags[ii].goals;
					s += ")";
				}

				sendPrivate(p, s);
			}
		}
	}
}

void botInfo::gotRemoteHelp(char *p, Command *c, Operator_Level l)
{
	// List commands

	if (!*c->final)
	{
		switch (l)
		{
		case OP_Duke:
		case OP_Baron:
		case OP_King:
		case OP_Emperor:
		case OP_RockStar:
		case OP_Q:
		case OP_God:
		case OP_Owner:
			{	// Owner-level commands
			}
		case OP_SysOp:
			{	// SysOp-level commands
			}
		case OP_SuperModerator:
			{	// SuperModerator-level commands
			}
		case OP_Moderator:
			{	// Moderator-level commands
			}
		case OP_Limited:
			{	// Limited-level commands
			}
		case OP_Player:
			{	// Player-level commands
			}
		}

		return;
	}

	// Specific command help

	switch (l)
	{
	case OP_Duke:
	case OP_Baron:
	case OP_King:
	case OP_Emperor:
	case OP_RockStar:
	case OP_Q:
	case OP_God:
	case OP_Owner:
		{	// Owner-level commands
		}
	case OP_SysOp:
		{	// SysOp-level commands
		}
	case OP_SuperModerator:
		{	// SuperModerator-level commands
		}
	case OP_Moderator:
		{	// Moderator-level commands
		}
	case OP_Limited:
		{	// Limited-level commands
		}
	case OP_Player:
		{	// Player-level commands
		}
	}
}

void botInfo::gotRemote(char *p, Command *c, Operator_Level l)
{
	if (!c) return;

	switch (l)
	{
	case OP_Duke:
	case OP_Baron:
	case OP_King:
	case OP_Emperor:
	case OP_RockStar:
	case OP_Q:
	case OP_God:
	case OP_Owner:
		{	// Owner-level commands
		}
	case OP_SysOp:
		{	// SysOp-level commands
		}
	case OP_SuperModerator:
		{	// SuperModerator-level commands
		}
	case OP_Moderator:
		{	// Moderator-level commands
		}
	case OP_Limited:
		{	// Limited-level commands
		}
	case OP_Player:
		{	// Player-level commands
		}
	}
}
