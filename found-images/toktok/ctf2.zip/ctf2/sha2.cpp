#include "sha2.h"
#include <string.h>

// Algorithm from FIPS180-2

// 4.1.2	SHA-256 Functions

#define Ch(x, y, z) (((x) & (y)) ^ (~(x) & (z)))
#define Maj(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define Sigma0(x) (ROR32(x,  2) ^ ROR32(x, 13) ^ ROR32(x, 22))
#define Sigma1(x) (ROR32(x,  6) ^ ROR32(x, 11) ^ ROR32(x, 25))
#define Gamma0(x) (ROR32(x,  7) ^ ROR32(x, 18) ^ ((x) >>  3))
#define Gamma1(x) (ROR32(x, 17) ^ ROR32(x, 19) ^ ((x) >> 10))

// 6.2.2	SHA-256 Hash Computation

#define STEP3(reg, t, w) \
{ \
	uint32 t1, t2; \
	t1 = reg[7] + Sigma1(reg[4]) + Ch(reg[4], reg[5], reg[6]) + SBOX[t] + w; \
	t2 = Sigma0(reg[0]) + Maj(reg[0], reg[1], reg[2]); \
	reg[7] = reg[6]; \
	reg[6] = reg[5]; \
	reg[5] = reg[4]; \
	reg[4] = reg[3] + t1; \
	reg[3] = reg[2]; \
	reg[2] = reg[1]; \
	reg[1] = reg[0]; \
	reg[0] = t1 + t2; \
}

namespace cat
{
	// 4.2.2	SHA-256 Constants
	// "These words represent the first thirty-two bits of the
	// fractional parts of the cube roots of the first 24 primes."

	const uint32 SBOX[64] = {
		0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
		0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
		0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
		0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
		0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
		0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
		0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
		0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
		0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
		0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
		0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
		0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
		0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
		0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
		0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
		0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
	};

	// 5.3.2	SHA-256 Initial hash value
	// "These words were obtained by taking the first 32 bits
	// of the factional parts of the square roots of the first
	// 8 prime numbers."

	static const uint32 Hi[8] = {
		0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
		0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
	};


	//////// 256-bit SHA2 ////////

	// call beginDigest()
	DigestSHA256::DigestSHA256()
	{
		beginDigest();
	}

	// zero register and work memory space
	DigestSHA256::~DigestSHA256()
	{
		highCounter = lowCounter = 0;

		MEMCLEAR32(reg, 8);
		MEMCLEAR32(workReg, 8);
		MEMCLEAR32(work, 64);
	}

	// initialize the 256-bit register
	void DigestSHA256::beginDigest()
	{
		highCounter = lowCounter = 0;

		MEMCOPY32(Hi, reg, 8);
		MEMCLEAR32(work, 64);
		MEMCLEAR32(workReg, 8);
	}

	// 6.2.2	SHA-256 Hash Computation

	void DigestSHA256::hashComputation()
	{
		uint32 ii;

		MEMCOPY32(reg, workReg, 8);

		for (ii = 0; ii < 16; ++ii)
		{
			work[ii] = BOSWAP32(work[ii]);

			STEP3(workReg, ii, work[ii]);
		}

		for (; ii < 64; ++ii)
		{
			uint32 Wt = Gamma1(work[ii - 2]) + work[ii - 7] + Gamma0(work[ii - 15]) + work[ii - 16];

			work[ii] = Wt;

			STEP3(workReg, ii, Wt);
		}

		MEMADD32(workReg, reg, 8);
	}

	// do SHA2 rounds
	void DigestSHA256::performDigest(char *buf, uint32 len)
	{
		if (len == 0) return;

		// compute number of complete blocks and
		// residual bytes this time
		uint32 fill = (lowCounter % 64);
		uint32 low = (len % 64) + fill;
		uint32 complete = low / 64 + len / 64;
		uint32 residual = low % 64;

		// we cannot do the hash computation from the
		// provided buffer, because we need 48 more
		// contiguous words
		if (complete)
		{
			if (fill)
			{
				memcpy((uint8*)work + fill, buf, 64 - fill);

				hashComputation();

				buf += 64 - fill;
				--complete;
			}

			while (complete--)
			{
				MEMCOPY32(buf, work, 16);

				hashComputation();

				buf += 64;
			}

			if (residual)
			{
				memcpy(work, buf, residual);
			}
		}
		else
		{
			memcpy((uint8*)work + fill, buf, len);
		}

		// update number of bytes hashed to register
		if ((lowCounter += len) < len)
			++highCounter;
	}

	// finish up by adding in the length of the input, then return the contents of the digest register
	uint32 *DigestSHA256::endDigest()
	{
		uint32 fill = (lowCounter % 64);

		// buffer actual data with a single bit
		((uint8*)work)[fill++] = 0x80;

		if (fill > 56)
		{
			memset((uint8*)work + fill, 0, 64 - fill);

			hashComputation();

			MEMCLEAR32(work, 16);
		}
		else
		{
			memset((uint8*)work + fill, 0, 56 - fill);
		}

		// convert the counters into bit-counts
		highCounter <<= 3;
		highCounter |= lowCounter >> (32 - 3);
		lowCounter <<= 3;

		// copy them to the high words of buffer, big-endian
		work[15] = BOSWAP32(lowCounter);
		work[14] = BOSWAP32(highCounter);

		hashComputation();

		highCounter = lowCounter = 0;

		MEMCLEAR32(work, 64);
		MEMCLEAR32(workReg, 8);

		return reg;
	}
}
