/*
	Mersenne Twister (MT19937)

	catid(cat02e@fsu.edu)

	7/28/2003	Went back to the MT website and updated algorithm
	7/8/2003	Added to project from FakeTCP library

	Tabs: 4 spaces
*/

#ifndef MERSENNE_H
#define MERSENNE_H

#include "types.h"

namespace cat
{
	const uint32 VECTOR_SPACE = 624;			/* Length of state vector, do not change */

	class RandomMT
	{
		uint32 state[VECTOR_SPACE];	/* State vector, additional space recommended by Shawn */
		uint32 *next;				/* Next random value is computed from here */
		sint32 left;				/* Can *next++ this many times before reloading */

	public:
		RandomMT();
		~RandomMT();

		void reload();

		void seed(uint32 seed);
		void seed(char *buf, uint32 len);
		uint32 *seed();

		bool random_bool();
		uint32 random();
		uint32 random(sint32 start, sint32 end);
		uint32 random_nt();
		uint32 get(uint16 i);
		void random_nt_series(uint32 len, uint32 *buf);
	};
}

#endif // MERSENNE_H
