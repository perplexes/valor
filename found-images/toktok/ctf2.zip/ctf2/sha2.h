/*
	SHA-2

	catid(cat02e@fsu.edu)

	7/27/2003	Began writing

	TODO
		Check rounds for correctness
		Use proper byte order

	Tabs: 4 spaces
*/

#ifndef SHA2_H
#define SHA2_H

#include "types.h"

namespace cat
{
	//////// 256-bit SHA2 ////////

	/*
		Encapsulated 256-bit message digest algorithm

		Pseudo-code for normal operation:
			DigestSHA256 sha2;
			sha2.beginDigest();	// redundant, this is called in the constructor
			sha2.performDigest(...);
			uint32[8] = sha2.endDigest();

		Please note that returned pointers are only valid until the next function call.
	*/
	class DigestSHA256
	{
		uint32 work[64];
		uint32 reg[8], workReg[8];
		uint32 highCounter, lowCounter;

		void hashComputation();

	public:
		// call beginDigest()
		DigestSHA256();

		// zero register and work memory space
		~DigestSHA256();

		// initialize the 256-bit register
		void beginDigest();

		// do SHA2 rounds
		void performDigest(char *buf, uint32 len);

		// finish up by adding in the length of the input, then return the contents of the digest register
		uint32 *endDigest();
	};
}

#endif // SHA2_H
