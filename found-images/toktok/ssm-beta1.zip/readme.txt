sprite sheet maker by smong [june 21 2005]
beta 1

You can use this java app. to combine lots of seperate images into one big sprite sheet. Its intended use is for converting the output from 3d modelling programs into a subspace ship.

To use simply double click ssm.jar, or alternatively at a command prompt type java -jar ssm.jar


The source is included inside the .jar file, which can be opened with winzip or a similar program.

made with java 1.4.2 on linux
